package com.example.myapplication2.RecyclerView;


import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication2.Donnee;
import com.example.myapplication2.R;


public class MyViewHolder extends RecyclerView.ViewHolder{

    private TextView tvid;
    private TextView tvvolume;
    private TextView tvdeg;
    private TextView tvebc;

    //itemView est la vue correspondante à 1 cellule
    public MyViewHolder(View itemView) {
        super(itemView);
        //c'est ici que l'on fait nos findView
        tvid = (TextView) itemView.findViewById(R.id.tvl_id);
        tvvolume = (TextView) itemView.findViewById(R.id.tvl_volume);
        tvdeg = (TextView) itemView.findViewById(R.id.tvl_degre);
        tvebc= (TextView) itemView.findViewById(R.id.tvl_ebc);

    }

    //puis ajouter une fonction pour remplir la cellule en fonction d'un MyObject
    //callback// 2 - add callback reference to the signature
    public void bind(Donnee myObject){
        tvid.setText(myObject.getId().toString());
        tvvolume.setText(myObject.getVolume().toString());
        tvdeg.setText(myObject.getVolume().toString());
        tvebc.setText(myObject.getVolume().toString());
    }
}