package com.example.myapplication2;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class outil_de_fabric extends AppCompatActivity {
    Recette recette;
    View buttonClose;
    Button buttonCalcule;
    Button buttonEnregistrer;
    int volume;
    int degre;
    int ebc;
    View layout3;
    TextView bierre;
    TextView alcool;
    TextView gainne;
    TextView total0;
    TextView total1;
    TextView total2;
    TextView total3;
    TextView total4;
    TextView total6;
    TextView total5;
    TextView total7;
    TextView total8;
    TextView tvcolor;
    ArrayList total = new ArrayList();
    private AccesLocal accesLocal = new AccesLocal(this);
    String FichierSerialise = "valeurSerialise";


    private void recupSerialize(Context contexte){
        recette=(Recette) Serializer.deserialize(FichierSerialise, contexte);
    }

    private void checkSerialize(){
        try{
            recupSerialize(this);
            ((TextView) findViewById(R.id.vol_bierre)).setText("" + recette.getVolume());
            ((TextView) findViewById(R.id.deg_alcool)).setText("" + recette.getDegré());
            ((TextView) findViewById(R.id.ebc_graine)).setText("" + recette.getEbc());

            // findViewById(R.id.btn_save).performClick();
        }catch (Exception e){};
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.outil_de_fabrication);
        init();
        initListeBtn();
    }

    private void init() {
        associerView();
        buttonCalcule= findViewById(R.id.butonCalculer);
        buttonCalcule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtnCalculer​();
            }
        });
        buttonEnregistrer= findViewById(R.id.enregistrer);
        buttonEnregistrer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtnEnregistrer();
            }
        });
        buttonClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtnClose​();
            }
        });

        checkSerialize();
    }

    public void ecouteBtnCalculer​(){
        hideKeyboard(outil_de_fabric.this);
        //layout3.setVisible();
        total0.setTextColor(Color.BLACK);
        layout3.setVisibility(View.VISIBLE);
        volume = Integer.parseInt(bierre.getText().toString());
        degre = Integer.parseInt(alcool.getText().toString());
        ebc = Integer.parseInt(gainne.getText().toString());

        recette= new Recette(volume,degre,ebc);

        total0.setText(String.format("Quantité de malt :%f kg",recette.malt()));
        total1.setText(String.format("Volume d'eau de Brassage :%f L",recette.brassage()));
        total2.setText(String.format("Volume d'eau de rinçage :%f L",recette.rincage()));
        total3.setText(String.format("Quantité de houblon amérisant :%f g",recette.hAmerisant()));
        total4.setText(String.format("Quantité de houblon aromatique :%f g",recette.hAromatique()));
        total5.setText(String.format("Quantité de levure :%f g",recette.levure()));

        String rgb = recette.srmToRGB(recette.srm());
        tvcolor.setBackgroundColor(Color.parseColor(rgb));
        total6.setText(String.format("MCU=%f",recette.mcu()));
        total7.setText(String.format("EBC=%f",recette.ebc()));
        total8.setText(String.format("SRM=:%f",recette.srm()));

        recette =new Recette(volume,degre,ebc);
        Serializer.serialize(FichierSerialise, recette, outil_de_fabric.this);
    }

    // fonction permettant la fermeture d’une activity en cliquant sur un bouton
    // ( équivalence avec le bouton "back" d'android )
    private void ecouteBtnClose​(){
        buttonClose.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void ecouteBtnEnregistrer(){
        accesLocal.ajout(volume,degre,ebc);
        Toast.makeText(outil_de_fabric.this, "Saisie enregistrée.", Toast.LENGTH_SHORT).show();
    }

    public static void hideKeyboard(outil_de_fabric activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(outil_de_fabric.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private void associerView(){
        buttonClose= findViewById(R.id.menu);
        bierre = findViewById(R.id.vol_bierre);
        alcool= findViewById(R.id.deg_alcool);
        gainne= findViewById(R.id.ebc_graine);
        total0= findViewById(R.id.total0);
        total1= findViewById(R.id.total1);
        total2= findViewById(R.id.total2);
        total3= findViewById(R.id.total3);
        total4= findViewById(R.id.total4);
        total5= findViewById(R.id.total5);
        total6= findViewById(R.id.total6);
        total7= findViewById(R.id.total7);
        total8= findViewById(R.id.total8);
        tvcolor= findViewById(R.id.textcolor);
        layout3= findViewById(R.id.layoutCalculer);
    }

    private void initListeBtn(){
        total.add(total0);
        total.add(total1);
        total.add(total2);
        total.add(total3);
        total.add(total4);
        total.add(total5);
        total.add(total6);
        total.add(total7);
        total.add(total8);
    }

}

