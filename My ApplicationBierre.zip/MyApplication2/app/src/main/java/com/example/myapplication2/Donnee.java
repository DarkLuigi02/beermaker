package com.example.myapplication2;

public class Donnee {

    //attribut
    Integer id;
    Integer volume;
    Integer degre;
    Integer ebc;

    public Donnee(Integer id, Integer volume, Integer degre, Integer ebc) {
        this.id = id;
        this.volume = volume;
        this.degre = degre;
        this.ebc = ebc;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getVolume() {
        return volume;
    }

    public void setVolume(Integer volume) {
        this.volume = volume;
    }

    public Integer getDegre() {
        return degre;
    }

    public void setDegre(Integer degre) {
        this.degre = degre;
    }

    public Integer getEbc() {
        return ebc;
    }

    public void setEbc(Integer ebc) {
        this.ebc = ebc;
    }





}
