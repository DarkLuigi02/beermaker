package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.myapplication2.RecyclerView.MyAdapter;

import java.util.ArrayList;

public class Vosrecette extends AppCompatActivity {

    // attribut
    private Donnee donnee;
    private AccesLocal accesLocal;
    private RecyclerView rvListe;
    Button vider;
    Button buttonSelectionner;
    Button buttonPrecedant;
    Button buttonSuivant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vosrecette);
        init();
    }

    private void init() {
        accesLocal = new AccesLocal(this);
        vider = findViewById(R.id.btnvider);
        buttonSelectionner = findViewById(R.id.selctionner);
        buttonPrecedant = findViewById(R.id.precedant);
        buttonSuivant = findViewById(R.id.suivant);

        vider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtn();
            }
        });
        buttonSelectionner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtn4​();
            }
        });
        buttonSuivant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtnSuivant();
            }
        });
        buttonPrecedant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtnPrecedant();
            }
        });
        noFocusOnLayout(this);


        //checkBDLocal();
        //gestion de la liste dans le onResume()
    }

    private void ecouteBtn() {
                //Toast.makeText(MainActivity.this, "Saisie enregistrée.", Toast.LENGTH_SHORT).show();
        vider.setOnClickListener(new TextView.OnClickListener() {
            public void onClick(View v) {
                accesLocal.vider();
                onResume();
            }
        });
    }

    private void checkBDLocal(){
        donnee = accesLocal.recupDernierEnreg();
        ((TextView) findViewById(R.id.tvl_id)).setText("Id : " + donnee.getId());
        ((TextView) findViewById(R.id.tvl_volume)).setText("volume : " +donnee.getVolume());
        ((TextView) findViewById(R.id.tvl_degre)).setText("degre : "+donnee.getDegre());
        ((TextView) findViewById(R.id.tvl_ebc)).setText("ebc : "+donnee.getEbc());


        }

    private void ecouteBtn4​(){
        Intent intent = new Intent(Vosrecette.this, outil_de_fabric.class);
        startActivity(intent);
        ecouteBtnCalculer​();

    }

    private void ecouteBtnPrecedant(){

    }

    private void ecouteBtnSuivant(){
    }

    @Override
    protected void onResume() {
        try {
            checkBDLocal();
            //on récupére la liste des donnees
            ArrayList<Donnee> listeDonnee = accesLocal.recupEtoile();

            //On met en mémoire notre adaptateur et nous lui donnons notre liste de Donnee
            rvListe = (RecyclerView) findViewById(R.id.rvliste) ;
            rvListe.setLayoutManager(new LinearLayoutManager(this));
            //On donne à notre RecyclerViex notre nouvel adaptateur
            rvListe.setAdapter(new MyAdapter(listeDonnee));
        }catch (Exception e){
            Log.d("log","erreur Bdd");
        }
        super.onResume();
    }


    public void noFocusOnLayout(Activity activity) {
        LinearLayout view = findViewById(R.id.valeur);
        view.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);
        view.setFocusable(true);
        view.setFocusableInTouchMode(true);
        view.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch (View v, MotionEvent event){
                v.requestFocusFromTouch();
                return false;
            }
        });
    }

}

