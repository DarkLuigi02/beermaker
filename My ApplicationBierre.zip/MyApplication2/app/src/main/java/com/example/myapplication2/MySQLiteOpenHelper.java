package com.example.myapplication2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MySQLiteOpenHelper extends SQLiteOpenHelper {

    private String create = " create table demosqlite (" +
            "id INTEGER PRIMARY KEY, "+
            "volume INTEGER NOT NULL, "+
            "degre INTEGER NOT NULL, "+
            "ebc INTEGER NOT NULL);";
    public MySQLiteOpenHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String create="Create Table demosqlite (id Integer, volume Integer, degre Integer, ebc Integer , PRIMARY KEY (`id`))";
        db.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
