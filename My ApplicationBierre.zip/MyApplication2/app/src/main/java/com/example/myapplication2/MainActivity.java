package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button Activity1;
    Button Activity2;
    Button Activity3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        Activity1 = findViewById(R.id.btn1);
        Activity2 = findViewById(R.id.btn2);
        Activity3 = findViewById(R.id.btn3);
        Activity1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtn1​();
            }
        });
        Activity2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtn2​();
            }
        });
        Activity3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtn3​();
            }
        });
    }

    private void ecouteBtn1​(){
                Intent intent = new Intent(MainActivity.this, etape_de_fabric.class);
                startActivity(intent);
    }

    private void ecouteBtn2​(){
                 Intent intent = new Intent(MainActivity.this, outil_de_fabric.class);
                startActivity(intent);
    }

    private void ecouteBtn3​(){
                 Intent intent = new Intent(MainActivity.this, Vosrecette.class);
                startActivity(intent);
    }

    //%s = String %d= entier %f = réel
}
