package com.example.myapplication2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class etape_de_fabric extends AppCompatActivity {
    View buttonNext;
    View buttonprevious;
    View layout1;
    View layout2;
    View layout3;
    View layout4;
    View layout5;
    View layout6;
    View layout7;
    View buttonClose;
    ArrayList<View> allLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.etape_de_fabrication);
        initView();
        initList();
        init();
    }

    private void init() {
        for (View layout : allLayout) {
            layout.setActivated(false);
            layout.setVisibility(View.GONE);
        }
        layout1.setVisibility(View.VISIBLE);
        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtnnext();
            }
        });
        buttonprevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtnprevious();
            }
        });
        buttonClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ecouteBtnClose​();
            }
        });
    }

    private void initView() {
        buttonNext = findViewById(R.id.next);
        buttonprevious = findViewById(R.id.previous);
        buttonClose= findViewById(R.id.menu);
        layout1 = findViewById(R.id.layout1);
        layout2 = findViewById(R.id.layout2);
        layout3 = findViewById(R.id.layout3);
        layout4 = findViewById(R.id.layout4);
        layout5 = findViewById(R.id.layout5);
        layout6 = findViewById(R.id.layout6);
        layout7 = findViewById(R.id.layout7);
    }

    private void initList(){
        ArrayList<View> allLayout=new ArrayList<>();
        allLayout.add(layout1);
        allLayout.add(layout2);
        allLayout.add(layout3);
        allLayout.add(layout4);
        allLayout.add(layout5);
        allLayout.add(layout6);
        allLayout.add(layout7);
    }

    private void ecouteBtnnext(){
        if (buttonprevious.getVisibility()==View.INVISIBLE){
        buttonprevious.setVisibility(View.VISIBLE);
        }
        for (View layout : allLayout) {
            View lastlayout= allLayout.get(allLayout.size()-1);
            if (layout.getVisibility()== View.VISIBLE) {
                int id=layout.getId();
                if (id==lastlayout.getId()){
                    buttonNext.setVisibility(View.INVISIBLE);
                }
                layout.setActivated(false);
                View a = allLayout.get(id+1);
                a.setVisibility(View.VISIBLE);
                a.setActivated(true);
            }
        }
    }

    private void ecouteBtnprevious(){
        for (View layout : allLayout) {
            if (layout.getVisibility()== View.VISIBLE) {
                int id=layout.getId();
                if (id==layout1.getId()){
                    buttonprevious.setVisibility(View.INVISIBLE);
                }
                layout.setActivated(false);
                View a = allLayout.get(id-1);
                a.setVisibility(View.VISIBLE);
                a.setActivated(true);
            }
        }
    }

    private void ecouteBtnClose​(){
        buttonClose.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}